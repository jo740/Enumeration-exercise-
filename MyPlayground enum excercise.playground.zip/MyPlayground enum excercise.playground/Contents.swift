import UIKit

enum Sandwitchingredients: CaseIterable {
    case lettuce, tomato, mayo, wheatbread, bologna, pepper
}
let Completesandwitch = Sandwitchingredients.allCases.count
print("There are -> \(Completesandwitch) sandwitch available")

for sandwitch in Sandwitchingredients.allCases {
    print(sandwitch)
}
